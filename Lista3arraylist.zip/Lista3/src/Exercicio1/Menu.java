package Exercicio1;

import javax.swing.JOptionPane;

public class Menu {
//ctrl + espaco

    public static void main(String[] args) {
        int opcao;

        do {
            System.out.println("MENU ");//Menu:
            System.out.println("1-Criar Curso");//1 – Criar Curso
            System.out.println("2- Criar Aluno");//2 – Criar Aluno (Perguntar os dados do aluno e escolher o curso do aluno)
            System.out.println("3- Remover Aluno");//3 – Remover Aluno
            System.out.println("4 -Mostrar todos os cursos");//4 – Mostrar Todos os Cursos
            System.out.println("5- Mostrar alunos do curso");//5 – Mostrar alunos do curso
            System.out.println("6-Sair");//6 – Sair

            opcao = Integer.parseInt(JOptionPane.showInputDialog(null, " Escolha uma opcao:", "Opcao",
                    JOptionPane.QUESTION_MESSAGE));

            //if e else ou switch
            switch (opcao) {
                case 1:
                    System.out.println("Opção escolhida: Criar Curso");
                    break;
                case 2:
                    System.out.println("Opção escolhida: Criar Aluno");
                    break;
                case 3:
                    System.out.println("Opção escolhida: Remover Aluno");
                    break;
                case 4:
                    System.out.println("Opção escolhida: Mostrar todos os cursos");
                    break;
                case 5:
                    System.out.println("Opção escolhida: Mostrar alunos do curso");
                    break;
                case 6:
                    System.out.println("Opção escolhida: Sair");
                    break;
                default:
                    System.out.println("Opção Invalida");

            }
        } while(opcao!=6);

    }
}
