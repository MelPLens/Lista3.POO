
package Exercicio1;

import java.util.ArrayList;

public class Curso {
    
    private int codigo;
    private String nome;
    private int cargaHoraria;
    private ArrayList<Aluno> alunos = new ArrayList<>();

// metodo construtor PADRAO
   public Curso(){ 
       
}

    public Curso(int codigo, String nome,int cargaHoraria){ 
       this.cargaHoraria=cargaHoraria;
       this.codigo=codigo;
       this.nome=nome;
       
    }
    public void inserirAluno(Aluno alunos){
      alunos.add(alunos); 
  }
  
  public void removerAluno(int index){
        getAlunos().remove(index); 
      
  }
    //Retornar uma String com todos os dados do curso.
          public String imprimir(){
                 return "Nome : " + nome +
                 "\nCodigo :" + codigo()+
                 "\nCarga Horaria :" + cargaHoraria;

        
          }
            public String imprimirCompleto(){
                 return "Nome : " + nome +
                 "\nCodigo :" + codigo+
                 "\nCarga Horaria :" + cargaHoraria+
                 "\nAlunos :" + alunos;
                     
   
        
          }
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cargaHoraria
     */
    public int getCargaHoraria() {
        return cargaHoraria;
    }

    /**
     * @param cargaHoraria the cargaHoraria to set
     */
    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    /**
     * @return the alunos
     */
    public ArrayList<Aluno> getAlunos() {
        return alunos;
    }

    /**
     * @param alunos the alunos to set
     */
    public void setAlunos(ArrayList<Aluno> alunos) {
        this.alunos = alunos;
    }

  
    public int getCodigo() {
        return codigo;
        
        
        
    }

    private String codigo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
  
  }

  
  