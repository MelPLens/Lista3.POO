
package Exercicio2;


import java.util.ArrayList;


public class Automovel extends Pessoa {
   

    
    private int marca;
    private String modelo;
    private ArrayList<Automovel> automoveis = new ArrayList<>();

// metodo construtor PADRAO
   public Automovel(){ 
       
}

    public Automovel(int marca, String modelo){
       this.marca=marca;
       this.modelo=modelo;
       
    }
  
    //Retornar uma String com todos os dados do curso.
          public String imprimir(){
                 return "Marca : " + marca+
                 "\nModelo :" + modelo;

    }

          // SET E GETS
    
    public int getMarca() {
        return marca;
    }

   
    public void setMarca(int marca) {
        this.marca = marca;
    }

   
    public String getModelo() {
        return modelo;
    }

    
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

  
    public ArrayList<Automovel> getAutomoveis() {
        return automoveis;
    }

  
    public void setAutomoveis(ArrayList<Automovel> automoveis) {
        this.automoveis = automoveis;
    }

    void add(Automovel automoveis) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private Object getAutomovel() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

          
}
