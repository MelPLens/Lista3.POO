
package Exercicio2;

import javax.swing.JOptionPane;


public class Menu {
//Menu:
//1 – Criar Pessoa
//2 – Criar Automóvel
//3 – Transferir Automóvel (usuário seleciona a pessoa de origem e o seu automóvel e escolhe a pessoa de destino. O automóvel é excluído de um e inserido no outro).
//4 – Mostrar Todas as Pessoas
//5 – Mostrar automóvel da pessoa (mostrar as pessoas para ele escolher e listar os automóveis dessa)
//6 – Sair

   
    public static void main(String[] args) {
        int opcao;

        do {
            System.out.println("MENU ");
            System.out.println("1-Criar Pessoa");
            System.out.println("2- Criar Automovel");
            System.out.println("3- Transferir Automovel");
            System.out.println("4 -Mostrar todas pessoas");
            System.out.println("5- Mostrar automovel da pessoa");
            System.out.println("6-Sair");

            opcao = Integer.parseInt(JOptionPane.showInputDialog(null, " Escolha uma opcao:", "Opcao",
                    JOptionPane.QUESTION_MESSAGE));

            //if e else ou switch
            switch (opcao) {
                case 1:
                    System.out.println("Opção escolhida: Criar Pessoa");
                    break;
                case 2:
                    System.out.println("Opção escolhida: Criar Automovel");
                    break;
                case 3:
                    System.out.println("Opção escolhida: Transferir Automovel");
                    break;
                case 4:
                    System.out.println("Opção escolhida: Mostrar todas pessoas");
                    break;
                case 5:
                    System.out.println("Opção escolhida: Mostrar automovel da pessoa");
                    break;
                case 6:
                    System.out.println("Opção escolhida: Sair");
                    break;
                default:
                    System.out.println("Opção Invalida");

            }
        } while(opcao!=6);

    }
}

    

