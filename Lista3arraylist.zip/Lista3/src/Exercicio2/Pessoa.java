
package Exercicio2;

import java.util.ArrayList;


public class Pessoa {
  
    
    private int codigo;
    private String nome;
    private ArrayList<Automovel> automoveis = new ArrayList<>();

// metodo construtor PADRAO
   public Pessoa(){ 
       
}

    public Pessoa(int codigo, String nome){
       this.codigo=codigo;
       this.nome=nome;
       
    }
    public void inserirAutomovel(Automovel automoveis){
      automoveis.add(automoveis); 
  }
  
  public void removerAutomovel(int index){
        automoveis.remove(index); 
      
  }
    //Retornar uma String com todos os dados do curso.
          public String imprimir(){
                 return "Nome : " + getNome() +
                 "\nCodigo :" + getCodigo();

        
          }
            public String imprimirCompleto(){
                 return "Nome : " + getNome()+
                 "\nCodigo :" + getCodigo();
                     
   
        
          }
            
            

    private Object getAutomovel() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the automoveis
     */
    public ArrayList<Automovel> getAutomoveis() {
        return automoveis;
    }

    /**
     * @param automoveis the automoveis to set
     */
    public void setAutomoveis(ArrayList<Automovel> automoveis) {
        this.automoveis = automoveis;
    }
}
