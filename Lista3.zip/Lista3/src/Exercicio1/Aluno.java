
package Exercicio1;


class Aluno {
 private String RA;
 private String nome;
 
 
  public Aluno(){ // construtor
       
}

    public Aluno(String nome,String RA){ 
       this.nome=nome;
       this.RA=RA;
      
    
    }
 
    void add(Aluno alunos) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    public String getRA() {
        return RA;
    }

    
    public void setRA(String RA) {
        this.RA = RA;
    }

    
    public String getNome() {
        return nome;
    }

    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String imprimir(){
                 return "Nome : " + nome +
                 "\nRA :" + RA;
 
          }
}
