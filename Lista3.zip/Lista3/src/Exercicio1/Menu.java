
package Exercicio1;


public class Menu {
//Menu:
//1 – Criar Curso
//2 – Criar Aluno (Perguntar os dados do aluno e escolher o curso do aluno)
//3 – Remover Aluno
//4 – Mostrar Todos os Cursos
//5 – Mostrar alunos do curso
//6 – Sair

  
    public static void main(String[] args) {
        
    }
    
}
